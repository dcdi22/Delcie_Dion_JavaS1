package com.company.DelcieDionU1M5Summative;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DelcieDionU1M5SummativeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DelcieDionU1M5SummativeApplication.class, args);
	}

}

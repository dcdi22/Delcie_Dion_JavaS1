package com.company.DelcieDionU1Capstone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DelcieDionU1CapstoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(DelcieDionU1CapstoneApplication.class, args);
	}

}
